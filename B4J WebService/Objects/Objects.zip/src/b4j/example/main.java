package b4j.example;


import anywheresoftware.b4a.BA;

public class main extends Object{
public static main mostCurrent = new main();

public static BA ba;
static {
		ba = new  anywheresoftware.b4a.StandardBA("b4j.example", "b4j.example.main", null);
		ba.loadHtSubs(main.class);
        if (ba.getClass().getName().endsWith("ShellBA")) {
			
			ba.raiseEvent2(null, true, "SHELL", false);
			ba.raiseEvent2(null, true, "CREATE", true, "b4j.example.main", ba);
		}
	}
    public static Class<?> getObject() {
		return main.class;
	}

 
    public static void main(String[] args) throws Exception{
        try {
            anywheresoftware.b4a.keywords.Common.LogDebug("Program started.");
            initializeProcessGlobals();
            ba.raiseEvent(null, "appstart", (Object)args);
        } catch (Throwable t) {
			BA.printException(t, true);
		
        } finally {
            anywheresoftware.b4a.keywords.Common.LogDebug("Program terminated (StartMessageLoop was not called).");
        }
    }
public static anywheresoftware.b4a.keywords.Common __c = null;
public static anywheresoftware.b4j.object.ServerWrapper _srvr = null;
public static anywheresoftware.b4a.objects.collections.Map _msj = null;
public static int _reload = 0;
public static String _nombrearchivo = "";
public static anywheresoftware.b4j.object.JServlet.ServletResponseWrapper _respuesta = null;
public static b4j.example.httputils2service _httputils2service = null;
public static String  _appstart(String[] _args) throws Exception{
 //BA.debugLineNum = 18;BA.debugLine="Sub AppStart (Args() As String)";
 //BA.debugLineNum = 19;BA.debugLine="srvr.Initialize(\"srvr\")";
_srvr.Initialize(ba,"srvr");
 //BA.debugLineNum = 20;BA.debugLine="srvr.Port = 55555";
_srvr.setPort((int) (55555));
 //BA.debugLineNum = 21;BA.debugLine="srvr.StaticFilesFolder = File.Combine(File.DirApp";
_srvr.setStaticFilesFolder(anywheresoftware.b4a.keywords.Common.File.Combine(anywheresoftware.b4a.keywords.Common.File.getDirApp(),"www"));
 //BA.debugLineNum = 23;BA.debugLine="srvr.AddWebSocket(\"/AgregarFactura\", \"AgregarFact";
_srvr.AddWebSocket("/AgregarFactura","AgregarFactura");
 //BA.debugLineNum = 24;BA.debugLine="srvr.AddWebSocket(\"/ws\", \"B4A\")";
_srvr.AddWebSocket("/ws","B4A");
 //BA.debugLineNum = 25;BA.debugLine="srvr.AddHandler(\"/upload/v2/*\", \"hUploadServer\",";
_srvr.AddHandler("/upload/v2/*","hUploadServer",anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 26;BA.debugLine="srvr.Start";
_srvr.Start();
 //BA.debugLineNum = 27;BA.debugLine="StartMessageLoop";
anywheresoftware.b4a.keywords.Common.StartMessageLoop(ba);
 //BA.debugLineNum = 29;BA.debugLine="msj.Initialize";
_msj.Initialize();
 //BA.debugLineNum = 33;BA.debugLine="End Sub";
return "";
}

private static boolean processGlobalsRun;
public static void initializeProcessGlobals() {
    
    if (main.processGlobalsRun == false) {
	    main.processGlobalsRun = true;
		try {
		        main._process_globals();
httputils2service._process_globals();
		
        } catch (Exception e) {
			throw new RuntimeException(e);
		}
    }
}public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 10;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 11;BA.debugLine="Private srvr As Server";
_srvr = new anywheresoftware.b4j.object.ServerWrapper();
 //BA.debugLineNum = 12;BA.debugLine="Public msj As Map";
_msj = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 13;BA.debugLine="Public reload As Int";
_reload = 0;
 //BA.debugLineNum = 14;BA.debugLine="Public NombreArchivo As String";
_nombrearchivo = "";
 //BA.debugLineNum = 15;BA.debugLine="Public respuesta As ServletResponse";
_respuesta = new anywheresoftware.b4j.object.JServlet.ServletResponseWrapper();
 //BA.debugLineNum = 16;BA.debugLine="End Sub";
return "";
}
}
