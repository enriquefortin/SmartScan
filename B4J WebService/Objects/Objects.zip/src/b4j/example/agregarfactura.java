package b4j.example;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class agregarfactura extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4a.StandardBA("b4j.example", "b4j.example.agregarfactura", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.example.agregarfactura.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public anywheresoftware.b4j.object.WebSocket _ws = null;
public anywheresoftware.b4j.object.WebSocket.JQueryElement _txtempresa = null;
public anywheresoftware.b4j.object.WebSocket.JQueryElement _txtcai = null;
public anywheresoftware.b4j.object.WebSocket.JQueryElement _txtrtn = null;
public anywheresoftware.b4j.object.WebSocket.JQueryElement _txtmontototal = null;
public anywheresoftware.b4j.object.WebSocket.JQueryElement _txtmensaje = null;
public anywheresoftware.b4j.object.WebSocket.JQueryElement _filenamedisplay = null;
public anywheresoftware.b4j.object.WebSocket.JQueryElement _jqm = null;
public anywheresoftware.b4a.objects.Timer _timer1 = null;
public anywheresoftware.b4a.objects.collections.Map _langmap = null;
public anywheresoftware.b4a.objects.collections.List _langlist = null;
public boolean _tesseractinstalled = false;
public b4j.example.main _main = null;
public b4j.example.httputils2service _httputils2service = null;
public boolean  _application_error(anywheresoftware.b4a.objects.B4AException _error,String _stacktrace) throws Exception{
 //BA.debugLineNum = 140;BA.debugLine="Sub Application_Error (Error As Exception, StackTr";
 //BA.debugLineNum = 141;BA.debugLine="Log(\"Error\")";
__c.LogImpl("5786433","Error",0);
 //BA.debugLineNum = 142;BA.debugLine="Return True";
if (true) return __c.True;
 //BA.debugLineNum = 143;BA.debugLine="End Sub";
return false;
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 2;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 3;BA.debugLine="Private ws As WebSocket";
_ws = new anywheresoftware.b4j.object.WebSocket();
 //BA.debugLineNum = 4;BA.debugLine="Private txtempresa, txtcai, txtrtn, txtmontototal";
_txtempresa = new anywheresoftware.b4j.object.WebSocket.JQueryElement();
_txtcai = new anywheresoftware.b4j.object.WebSocket.JQueryElement();
_txtrtn = new anywheresoftware.b4j.object.WebSocket.JQueryElement();
_txtmontototal = new anywheresoftware.b4j.object.WebSocket.JQueryElement();
_txtmensaje = new anywheresoftware.b4j.object.WebSocket.JQueryElement();
_filenamedisplay = new anywheresoftware.b4j.object.WebSocket.JQueryElement();
_jqm = new anywheresoftware.b4j.object.WebSocket.JQueryElement();
 //BA.debugLineNum = 5;BA.debugLine="Private timer1 As Timer";
_timer1 = new anywheresoftware.b4a.objects.Timer();
 //BA.debugLineNum = 6;BA.debugLine="Private langmap As Map";
_langmap = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 7;BA.debugLine="Private langlist As List";
_langlist = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 8;BA.debugLine="Private tesseractInstalled As Boolean = True";
_tesseractinstalled = __c.True;
 //BA.debugLineNum = 9;BA.debugLine="End Sub";
return "";
}
public String  _device_message(anywheresoftware.b4a.objects.collections.Map _params) throws Exception{
 //BA.debugLineNum = 23;BA.debugLine="Sub Device_Message(Params As Map)";
 //BA.debugLineNum = 26;BA.debugLine="Main.msj=Params";
_main._msj /*anywheresoftware.b4a.objects.collections.Map*/  = _params;
 //BA.debugLineNum = 27;BA.debugLine="Log(Main.msj.Get(\"message\"))";
__c.LogImpl("5327684",BA.ObjectToString(_main._msj /*anywheresoftware.b4a.objects.collections.Map*/ .Get((Object)("message"))),0);
 //BA.debugLineNum = 28;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 11;BA.debugLine="Public Sub Initialize";
 //BA.debugLineNum = 13;BA.debugLine="End Sub";
return "";
}
public String  _jqm_click(anywheresoftware.b4a.objects.collections.Map _params) throws Exception{
 //BA.debugLineNum = 132;BA.debugLine="Private Sub jqm_Click(params As Map)";
 //BA.debugLineNum = 133;BA.debugLine="Log(\"CLICK\")";
__c.LogImpl("5720897","CLICK",0);
 //BA.debugLineNum = 134;BA.debugLine="txtmensaje.SetHtml(Main.msj.Get(\"message\"))";
_txtmensaje.SetHtml(BA.ObjectToString(_main._msj /*anywheresoftware.b4a.objects.collections.Map*/ .Get((Object)("message"))));
 //BA.debugLineNum = 135;BA.debugLine="End Sub";
return "";
}
public String  _leertesseract() throws Exception{
anywheresoftware.b4j.objects.Shell _sh = null;
 //BA.debugLineNum = 31;BA.debugLine="Sub leertesseract'_Click(Params As Map)";
 //BA.debugLineNum = 32;BA.debugLine="Log(\"click al boton leertesseract\")";
__c.LogImpl("5393217","click al boton leertesseract",0);
 //BA.debugLineNum = 34;BA.debugLine="Dim sh As Shell";
_sh = new anywheresoftware.b4j.objects.Shell();
 //BA.debugLineNum = 35;BA.debugLine="sh.Initialize(\"sh\",\"tesseract\",Null)";
_sh.Initialize("sh","tesseract",(anywheresoftware.b4a.objects.collections.List) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.collections.List(), (java.util.List)(__c.Null)));
 //BA.debugLineNum = 36;BA.debugLine="sh.run(10000)";
_sh.Run(ba,(long) (10000));
 //BA.debugLineNum = 37;BA.debugLine="langmap.Initialize";
_langmap.Initialize();
 //BA.debugLineNum = 38;BA.debugLine="langlist.Initialize";
_langlist.Initialize();
 //BA.debugLineNum = 39;BA.debugLine="langlist.Add(\"spa_old\")";
_langlist.Add((Object)("spa_old"));
 //BA.debugLineNum = 40;BA.debugLine="langmap.Put(\"Español\",langlist.Get(0))";
_langmap.Put((Object)("Español"),_langlist.Get((int) (0)));
 //BA.debugLineNum = 41;BA.debugLine="Log(langlist)";
__c.LogImpl("5393226",BA.ObjectToString(_langlist),0);
 //BA.debugLineNum = 42;BA.debugLine="Log(langmap)";
__c.LogImpl("5393227",BA.ObjectToString(_langmap),0);
 //BA.debugLineNum = 43;BA.debugLine="Log(langmap.Get(\"Español\"))";
__c.LogImpl("5393228",BA.ObjectToString(_langmap.Get((Object)("Español"))),0);
 //BA.debugLineNum = 46;BA.debugLine="ProcessImage";
_processimage();
 //BA.debugLineNum = 51;BA.debugLine="End Sub";
return "";
}
public String  _ocr_finished(String _text,int _processingtime) throws Exception{
 //BA.debugLineNum = 146;BA.debugLine="Sub OCR_finished (Text As String,ProcessingTime As";
 //BA.debugLineNum = 147;BA.debugLine="Log(Text)";
__c.LogImpl("5851969",_text,0);
 //BA.debugLineNum = 148;BA.debugLine="Log(ProcessingTime & \" ms\")";
__c.LogImpl("5851970",BA.NumberToString(_processingtime)+" ms",0);
 //BA.debugLineNum = 149;BA.debugLine="End Sub";
return "";
}
public String  _ocr_overlay(anywheresoftware.b4a.objects.collections.Map _overlay) throws Exception{
 //BA.debugLineNum = 151;BA.debugLine="Sub OCR_overlay (Overlay As Map)";
 //BA.debugLineNum = 152;BA.debugLine="Log(Overlay)";
__c.LogImpl("5917505",BA.ObjectToString(_overlay),0);
 //BA.debugLineNum = 153;BA.debugLine="End Sub";
return "";
}
public String  _processimage() throws Exception{
String _uploadedimagepath = "";
anywheresoftware.b4a.objects.streams.File.InputStreamWrapper _inp = null;
anywheresoftware.b4a.objects.streams.File.OutputStreamWrapper _out = null;
 //BA.debugLineNum = 53;BA.debugLine="Sub ProcessImage";
 //BA.debugLineNum = 56;BA.debugLine="Dim uploadedImagePath As String = File.Combine(F";
_uploadedimagepath = __c.File.Combine(__c.File.getDirApp()+"/up","");
 //BA.debugLineNum = 59;BA.debugLine="Dim Inp As InputStream = File.OpenInput(uploaded";
_inp = new anywheresoftware.b4a.objects.streams.File.InputStreamWrapper();
_inp = __c.File.OpenInput(_uploadedimagepath,_main._nombrearchivo /*String*/ );
 //BA.debugLineNum = 62;BA.debugLine="Dim out As OutputStream = File.OpenOutput(File.D";
_out = new anywheresoftware.b4a.objects.streams.File.OutputStreamWrapper();
_out = __c.File.OpenOutput(__c.File.getDirApp()+"/tesseract-ocr","image.png",__c.False);
 //BA.debugLineNum = 65;BA.debugLine="File.Copy2(Inp, out)";
__c.File.Copy2((java.io.InputStream)(_inp.getObject()),(java.io.OutputStream)(_out.getObject()));
 //BA.debugLineNum = 68;BA.debugLine="out.Close";
_out.Close();
 //BA.debugLineNum = 71;BA.debugLine="scan";
_scan();
 //BA.debugLineNum = 73;BA.debugLine="Log(LastException)";
__c.LogImpl("5458772",BA.ObjectToString(__c.LastException(ba)),0);
 //BA.debugLineNum = 75;BA.debugLine="End Sub";
return "";
}
public String  _scan() throws Exception{
anywheresoftware.b4a.objects.collections.List _args = null;
anywheresoftware.b4j.objects.Shell _sh1 = null;
 //BA.debugLineNum = 79;BA.debugLine="Sub scan";
 //BA.debugLineNum = 80;BA.debugLine="Dim args As List";
_args = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 81;BA.debugLine="args.Initialize";
_args.Initialize();
 //BA.debugLineNum = 82;BA.debugLine="args.AddAll(Array As String(\"image.png\",\"output\",";
_args.AddAll(anywheresoftware.b4a.keywords.Common.ArrayToList(new String[]{"image.png","output","-l",BA.ObjectToString(_langmap.Get((Object)("Español")))}));
 //BA.debugLineNum = 83;BA.debugLine="Dim sh1 As Shell";
_sh1 = new anywheresoftware.b4j.objects.Shell();
 //BA.debugLineNum = 84;BA.debugLine="tesseractInstalled=True";
_tesseractinstalled = __c.True;
 //BA.debugLineNum = 85;BA.debugLine="If tesseractInstalled Then";
if (_tesseractinstalled) { 
 //BA.debugLineNum = 86;BA.debugLine="sh1.Initialize(\"sh1\",\"tesseract\",args)";
_sh1.Initialize("sh1","tesseract",_args);
 //BA.debugLineNum = 87;BA.debugLine="Log(\"iniciado\")";
__c.LogImpl("5524296","iniciado",0);
 //BA.debugLineNum = 88;BA.debugLine="Log(Main.NombreArchivo)";
__c.LogImpl("5524297",_main._nombrearchivo /*String*/ ,0);
 }else {
 //BA.debugLineNum = 90;BA.debugLine="sh1.Initialize(\"sh1\",File.Combine(File.Combine(F";
_sh1.Initialize("sh1",__c.File.Combine(__c.File.Combine(__c.File.getDirApp(),"tesseract-ocr"),"tesseract"),_args);
 //BA.debugLineNum = 91;BA.debugLine="Log(File.Combine(File.Combine(File.DirApp,\"tesse";
__c.LogImpl("5524300",__c.File.Combine(__c.File.Combine(__c.File.getDirApp(),"tesseract-ocr"),"tesseract"),0);
 };
 //BA.debugLineNum = 93;BA.debugLine="sh1.WorkingDirectory = File.Combine(File.DirApp,\"";
_sh1.setWorkingDirectory(__c.File.Combine(__c.File.getDirApp(),"tesseract-ocr"));
 //BA.debugLineNum = 94;BA.debugLine="sh1.run(100000)";
_sh1.Run(ba,(long) (100000));
 //BA.debugLineNum = 95;BA.debugLine="End Sub";
return "";
}
public String  _sh_processcompleted(boolean _success,int _exitcode,String _stdout,String _stderr) throws Exception{
 //BA.debugLineNum = 156;BA.debugLine="Sub sh_ProcessCompleted (Success As Boolean, ExitC";
 //BA.debugLineNum = 157;BA.debugLine="If Success And ExitCode = 0 Then";
if (_success && _exitcode==0) { 
 //BA.debugLineNum = 158;BA.debugLine="Log(\"Success\")";
__c.LogImpl("5983042","Success",0);
 //BA.debugLineNum = 159;BA.debugLine="Log(StdOut)";
__c.LogImpl("5983043",_stdout,0);
 //BA.debugLineNum = 160;BA.debugLine="tesseractInstalled=True";
_tesseractinstalled = __c.True;
 //BA.debugLineNum = 161;BA.debugLine="Log(\"Si\")";
__c.LogImpl("5983045","Si",0);
 }else {
 //BA.debugLineNum = 163;BA.debugLine="Log(\"Error: \" & StdErr)";
__c.LogImpl("5983047","Error: "+_stderr,0);
 //BA.debugLineNum = 164;BA.debugLine="tesseractInstalled=False";
_tesseractinstalled = __c.False;
 };
 //BA.debugLineNum = 166;BA.debugLine="End Sub";
return "";
}
public String  _sh1_processcompleted(boolean _success,int _exitcode,String _stdout,String _stderr) throws Exception{
 //BA.debugLineNum = 168;BA.debugLine="Sub sh1_ProcessCompleted (Success As Boolean, Exit";
 //BA.debugLineNum = 169;BA.debugLine="If Success And ExitCode = 0 Then";
if (_success && _exitcode==0) { 
 //BA.debugLineNum = 170;BA.debugLine="Log(\"Success\")";
__c.LogImpl("51048578","Success",0);
 //BA.debugLineNum = 171;BA.debugLine="Log(StdOut)";
__c.LogImpl("51048579",_stdout,0);
 //BA.debugLineNum = 173;BA.debugLine="txtmensaje.SetHtml(File.ReadString(File.Combine(";
_txtmensaje.SetHtml(__c.File.ReadString(__c.File.Combine(__c.File.getDirApp(),"tesseract-ocr"),"output.txt"));
 //BA.debugLineNum = 176;BA.debugLine="ws.Alert(\"Los resultados se han copiado en el po";
_ws.Alert("Los resultados se han copiado en el portapapeles.");
 }else {
 //BA.debugLineNum = 178;BA.debugLine="Log(ExitCode)";
__c.LogImpl("51048586",BA.NumberToString(_exitcode),0);
 //BA.debugLineNum = 179;BA.debugLine="Log(\"Error: \" & StdErr)";
__c.LogImpl("51048587","Error: "+_stderr,0);
 //BA.debugLineNum = 180;BA.debugLine="ws.Alert(\"fallo de reconocimiento\")";
_ws.Alert("fallo de reconocimiento");
 };
 //BA.debugLineNum = 183;BA.debugLine="End Sub";
return "";
}
public String  _timer1_tick() throws Exception{
 //BA.debugLineNum = 98;BA.debugLine="Sub Timer1_Tick";
 //BA.debugLineNum = 99;BA.debugLine="ws.RunFunction(\"ServerTime\", Array As Object(Date";
_ws.RunFunction("ServerTime",anywheresoftware.b4a.keywords.Common.ArrayToList(new Object[]{(Object)(__c.DateTime.Time(__c.DateTime.getNow()))}));
 //BA.debugLineNum = 100;BA.debugLine="ws.Flush";
_ws.Flush();
 //BA.debugLineNum = 101;BA.debugLine="If Main.reload=1 Then";
if (_main._reload /*int*/ ==1) { 
 //BA.debugLineNum = 102;BA.debugLine="ws.Eval($\"Swal.fire({    title: 'Los documentos";
_ws.Eval(("Swal.fire({\n"+"   title: 'Los documentos se han cargado con éxito',\n"+"   text: 'Documentación enviada.',\n"+"   icon: 'success',\n"+"   showConfirmButton: true\n"+"}).then((result) => {\n"+"   if (result.isConfirmed) {\n"+"     alertify.success('Documentación enviada.');\n"+"	 //document.location.replace('index.html');\n"+"   }\n"+"});"),(anywheresoftware.b4a.objects.collections.List) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.collections.List(), (java.util.List)(__c.Null)));
 //BA.debugLineNum = 113;BA.debugLine="Log(\"subido\")";
__c.LogImpl("5589839","subido",0);
 //BA.debugLineNum = 114;BA.debugLine="leertesseract";
_leertesseract();
 //BA.debugLineNum = 115;BA.debugLine="Main.reload=0";
_main._reload /*int*/  = (int) (0);
 };
 //BA.debugLineNum = 119;BA.debugLine="End Sub";
return "";
}
public String  _websocket_connected(anywheresoftware.b4j.object.WebSocket _websocket1) throws Exception{
 //BA.debugLineNum = 15;BA.debugLine="Private Sub WebSocket_Connected (WebSocket1 As Web";
 //BA.debugLineNum = 16;BA.debugLine="ws = WebSocket1";
_ws = _websocket1;
 //BA.debugLineNum = 18;BA.debugLine="timer1.Initialize(\"timer1\", 1000)";
_timer1.Initialize(ba,"timer1",(long) (1000));
 //BA.debugLineNum = 19;BA.debugLine="timer1.Enabled = True";
_timer1.setEnabled(__c.True);
 //BA.debugLineNum = 20;BA.debugLine="End Sub";
return "";
}
public String  _websocket_disconnected() throws Exception{
 //BA.debugLineNum = 121;BA.debugLine="Private Sub WebSocket_Disconnected";
 //BA.debugLineNum = 122;BA.debugLine="timer1.Enabled = False";
_timer1.setEnabled(__c.False);
 //BA.debugLineNum = 123;BA.debugLine="Log(\"disconnected\")";
__c.LogImpl("5655362","disconnected",0);
 //BA.debugLineNum = 124;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
