package b4j.example;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class huploadserver extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4a.StandardBA("b4j.example", "b4j.example.huploadserver", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.example.huploadserver.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public b4j.example.main _main = null;
public b4j.example.httputils2service _httputils2service = null;
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 2;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 4;BA.debugLine="End Sub";
return "";
}
public String  _handle(anywheresoftware.b4j.object.JServlet.ServletRequestWrapper _req,anywheresoftware.b4j.object.JServlet.ServletResponseWrapper _resp) throws Exception{
com.tummosoft.jFileUploadSupport _jupload = null;
String _pathupload = "";
 //BA.debugLineNum = 10;BA.debugLine="Sub Handle(req As ServletRequest, resp As ServletR";
 //BA.debugLineNum = 11;BA.debugLine="Dim jupload As jFileUploadSupport";
_jupload = new com.tummosoft.jFileUploadSupport();
 //BA.debugLineNum = 12;BA.debugLine="resp.SetHeader(\"Access-Control-Allow-Origin\", \"*\"";
_resp.SetHeader("Access-Control-Allow-Origin","*");
 //BA.debugLineNum = 13;BA.debugLine="jupload.Initialize(\"jupload\")";
_jupload.Initialize("jupload");
 //BA.debugLineNum = 14;BA.debugLine="Dim pathUpload As String = File.Combine(File.DirA";
_pathupload = __c.File.Combine(__c.File.getDirApp()+"/up","");
 //BA.debugLineNum = 15;BA.debugLine="jupload.TempFile(File.DirApp & \"www\", \"Multipart.";
_jupload.TempFile(__c.File.getDirApp()+"www","Multipart.temp");
 //BA.debugLineNum = 16;BA.debugLine="jupload.UploadPath(pathUpload)";
_jupload.UploadPath(_pathupload);
 //BA.debugLineNum = 17;BA.debugLine="jupload.MultipartHook(req)";
_jupload.MultipartHook(ba,(jakarta.servlet.http.HttpServletRequest)(_req.getObject()));
 //BA.debugLineNum = 18;BA.debugLine="Main.respuesta=resp";
_main._respuesta /*anywheresoftware.b4j.object.JServlet.ServletResponseWrapper*/  = _resp;
 //BA.debugLineNum = 21;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 6;BA.debugLine="Public Sub Initialize";
 //BA.debugLineNum = 8;BA.debugLine="End Sub";
return "";
}
public String  _jupload_uploadcompleted(boolean _success,String _filename) throws Exception{
 //BA.debugLineNum = 28;BA.debugLine="Sub jupload_UploadCompleted(Success As Boolean, Fi";
 //BA.debugLineNum = 29;BA.debugLine="Log(FileName)";
__c.LogImpl("51376257",_filename,0);
 //BA.debugLineNum = 30;BA.debugLine="Log(Success)";
__c.LogImpl("51376258",BA.ObjectToString(_success),0);
 //BA.debugLineNum = 31;BA.debugLine="Main.reload=1";
_main._reload /*int*/  = (int) (1);
 //BA.debugLineNum = 32;BA.debugLine="Main.NombreArchivo=FileName";
_main._nombrearchivo /*String*/  = _filename;
 //BA.debugLineNum = 33;BA.debugLine="End Sub";
return "";
}
public String  _jupload_uploadprogress(long _totalkb,String _percent) throws Exception{
 //BA.debugLineNum = 23;BA.debugLine="Sub jupload_UploadProgress (TotalKB As Long, Perce";
 //BA.debugLineNum = 24;BA.debugLine="Log(TotalKB)";
__c.LogImpl("51310721",BA.NumberToString(_totalkb),0);
 //BA.debugLineNum = 25;BA.debugLine="Log(Percent)";
__c.LogImpl("51310722",_percent,0);
 //BA.debugLineNum = 26;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
